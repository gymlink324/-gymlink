import { useState } from 'react';
import { MapPin, Search, CalendarCheck, Star } from 'lucide-react';
import { Button } from '../components/ui/button';

export default function Home() {
  return <div className="p-6 text-center text-xl font-bold">GymLink werkt! Voeg hier je componenten toe.</div>;
}
