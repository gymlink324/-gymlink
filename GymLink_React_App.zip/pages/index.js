import { useState } from 'react';
import { MapPin, Search, CalendarCheck, Star } from 'lucide-react';
import { Button } from '../components/ui/button';

export default function Home() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTrainer, setSelectedTrainer] = useState(null);
  const [bookingConfirmed, setBookingConfirmed] = useState(false);
  const [selectedTime, setSelectedTime] = useState(null);

  const sessions = [
    { id: 1, title: 'Strength Training', trainer: 'Luke', time: 'Today at 18:00', location: 'Amsterdam', price: '€30', rating: 4.8, bio: 'Ervaren personal trainer gespecialiseerd in krachttraining.', times: ['14:00', '15:30'] },
    { id: 2, title: 'Yoga', trainer: 'Sarah', time: 'Today at 19:00', location: 'Rotterdam', price: '€20', rating: 4.6, bio: 'Yogadocente met focus op ontspanning en flexibiliteit.', times: ['16:00', '18:00'] },
    { id: 3, title: 'HIIT', trainer: 'Mark', time: 'Tomorrow at 09:00', location: 'Utrecht', price: '€25', rating: 4.9, bio: 'HIIT-specialist met passie voor explosieve trainingen.', times: ['09:00', '10:30'] },
  ];

  const filteredSessions = sessions.filter(session =>
    session.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (bookingConfirmed) {
    return (
      <div className="p-6 max-w-xl mx-auto text-center">
        <h1 className="text-2xl font-bold mb-4">Boeking bevestigd!</h1>
        <p className="mb-4">Je hebt een sessie geboekt bij {selectedTrainer.trainer} om {selectedTime} in {selectedTrainer.location}.</p>
        <Button onClick={() => {
          setSelectedTrainer(null);
          setSelectedTime(null);
          setBookingConfirmed(false);
        }}>Terug naar overzicht</Button>
      </div>
    );
  }

  if (selectedTrainer && !selectedTime) {
    return (
      <div className="p-6 max-w-3xl mx-auto">
        <Button onClick={() => setSelectedTrainer(null)} className="mb-4">← Terug</Button>
        <h1 className="text-3xl font-bold mb-2">{selectedTrainer.trainer}</h1>
        <div className="text-sm text-gray-500 mb-2">{selectedTrainer.title} - {selectedTrainer.location}</div>
        <div className="flex items-center text-yellow-500 mb-4">
          <Star className="w-4 h-4 mr-1" /> {selectedTrainer.rating} / 5
        </div>
        <p className="mb-4">{selectedTrainer.bio}</p>
        <div className="text-lg font-bold">Prijs: {selectedTrainer.price}</div>
        <div className="mt-6">
          <h3 className="font-semibold mb-2">Kies een tijd</h3>
          <div className="flex gap-3">
            {selectedTrainer.times.map((time) => (
              <Button key={time} onClick={() => setSelectedTime(time)}>{time}</Button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (selectedTrainer && selectedTime) {
    return (
      <div className="p-6 max-w-xl mx-auto text-center">
        <h1 className="text-2xl font-bold mb-4">Bevestig je boeking</h1>
        <p className="mb-4">Trainer: {selectedTrainer.trainer}</p>
        <p className="mb-4">Tijd: {selectedTime}</p>
        <p className="mb-4">Locatie: {selectedTrainer.location}</p>
        <p className="mb-4 font-bold">Prijs: {selectedTrainer.price}</p>
        <Button className="mt-2" onClick={() => setBookingConfirmed(true)}>Bevestig Boeking</Button>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">Trainingssessies bij jou in de buurt</h1>
      <div className="flex gap-2 items-center mb-6">
        <Search className="text-gray-500" />
        <input
          type="text"
          placeholder="Zoek op trainingstype"
          className="border p-2 w-full rounded-xl"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>
      <div className="grid gap-4">
        {filteredSessions.map((session) => (
          <div key={session.id} className="border p-4 rounded-2xl shadow">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-xl font-semibold cursor-pointer hover:underline" onClick={() => setSelectedTrainer(session)}>{session.title}</h2>
                <p className="text-sm text-gray-500">Trainer: {session.trainer}</p>
                <div className="flex items-center text-sm text-gray-600 mt-1">
                  <CalendarCheck className="w-4 h-4 mr-1" /> {session.time}
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <MapPin className="w-4 h-4 mr-1" /> {session.location}
                </div>
              </div>
              <div className="text-right">
                <p className="text-lg font-bold">{session.price}</p>
                <Button className="mt-2" onClick={() => setSelectedTrainer(session)}>Bekijk profiel</Button>
              </div>
            </div>
          </div>
        ))}
        {filteredSessions.length === 0 && <p>Geen sessies gevonden.</p>}
      </div>
    </div>
  );
}
